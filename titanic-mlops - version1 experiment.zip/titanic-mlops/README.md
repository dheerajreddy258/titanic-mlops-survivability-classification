## Setup
- Install dependencies: `pip install -r requirements.txt`
- Download train.csv from Kaggle and place in data/

## Run Pipeline
- Prep data: `python src/prep_data.py`
- Train models: `python src/train.py`
- Evaluate: `python src/evaluate.py`
- Run API: `uvicorn api.main:app --reload`

## Deployment
- Build Docker: `docker build -t titanic-api .`
- Run Docker: `docker run -p 8000:8000 titanic-api`