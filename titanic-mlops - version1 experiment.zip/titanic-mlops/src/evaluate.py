import pandas as pd
import mlflow.sklearn
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

def evaluate_model():
    # Load test data
    X_test = pd.read_csv('data/titanic_clean_test.csv')
    y_test = pd.read_csv('data/titanic_clean_test_labels.csv').values.ravel()
    
    # Load best model from MLflow registry
    model_uri = "models:/TitanicBestModel/2"  # Version 1; update if different
    model = mlflow.sklearn.load_model(model_uri)
    
    y_pred = model.predict(X_test)
    
    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred)
    rec = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    
    print(f"Test Metrics: Accuracy={acc:.2f}, Precision={prec:.2f}, Recall={rec:.2f}, F1={f1:.2f}")

if __name__ == "__main__":
    evaluate_model()