import pandas as pd
import mlflow
import mlflow.sklearn
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

def train_models():
    # Load cleaned data
    X_train = pd.read_csv('data/titanic_clean_train.csv')
    y_train = pd.read_csv('data/titanic_clean_train_labels.csv').values.ravel()
    
    # Sample input for model signature
    input_example = X_train.head(1)  # Use one row as example
    
    models = {
        "LogisticRegression": LogisticRegression(max_iter=1000),
        "RandomForest": RandomForestClassifier(n_estimators=100, random_state=42),
        "GradientBoosting": GradientBoostingClassifier(n_estimators=100, random_state=42)
    }
    
    mlflow.set_experiment("Titanic_Survival_Experiments")
    
    for name, model in models.items():
        with mlflow.start_run(run_name=name):
            model.fit(X_train, y_train)
            
            # Log params and metrics
            y_pred = model.predict(X_train)
            acc = accuracy_score(y_train, y_pred)
            prec = precision_score(y_train, y_pred)
            rec = recall_score(y_train, y_pred)
            f1 = f1_score(y_train, y_pred)
            
            mlflow.log_params({"model_type": name})
            mlflow.log_metrics({"accuracy": acc, "precision": prec, "recall": rec, "f1": f1})
            # Log model with input example
            mlflow.sklearn.log_model(
                sk_model=model,
                artifact_path=f"{name}_model",  # Unique path per model
                input_example=input_example
            )
            
            # Register best model
            if name == "GradientBoosting":
                model_uri = f"runs:/{mlflow.active_run().info.run_id}/{name}_model"
                mlflow.register_model(model_uri, "TitanicBestModel")
    
    print("Models trained and logged in MLflow.")

if __name__ == "__main__":
    train_models()