import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

def prepare_data():
    # Load data
    df = pd.read_csv('data/train.csv')
    
    # Handle missing values
    df['Age'].fillna(df['Age'].median(), inplace=True)  # Fill Age with median
    df['Embarked'].fillna(df['Embarked'].mode()[0], inplace=True)  # Fill Embarked with mode
    df['Cabin'].fillna('Unknown', inplace=True)  # Flag missing Cabin
    
    # Engineer features
    df['IsChild'] = (df['Age'] < 18).astype(int)  # 1 if child
    df['FamilySize'] = df['SibSp'] + df['Parch'] + 1  # Total family
    df['Title'] = df['Name'].str.extract(' ([A-Za-z]+)\.', expand=False)  # Extract title from name
    df['Title'] = df['Title'].replace(['Lady', 'Countess', 'Capt', 'Col', 'Don', 'Dr', 'Major', 'Rev', 'Sir', 'Jonkheer', 'Dona'], 'Rare')
    df['Title'] = df['Title'].replace('Mlle', 'Miss').replace('Ms', 'Miss').replace('Mme', 'Mrs')
    
    # Encode categoricals
    le = LabelEncoder()
    df['Sex'] = le.fit_transform(df['Sex'])  # 0=female, 1=male
    df['Embarked'] = le.fit_transform(df['Embarked'])
    df['Title'] = le.fit_transform(df['Title'].fillna('Unknown'))
    
    # Drop unnecessary columns
    df.drop(['PassengerId', 'Name', 'Ticket', 'Cabin'], axis=1, inplace=True)
    
    # Split into features and target
    X = df.drop('Survived', axis=1)
    y = df['Survived']
    
    # Train-test split (80/20)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Save cleaned data
    X_train.to_csv('data/titanic_clean_train.csv', index=False)
    y_train.to_csv('data/titanic_clean_train_labels.csv', index=False)
    X_test.to_csv('data/titanic_clean_test.csv', index=False)
    y_test.to_csv('data/titanic_clean_test_labels.csv', index=False)
    
    print("Data prepared and saved.")

if __name__ == "__main__":
    prepare_data()