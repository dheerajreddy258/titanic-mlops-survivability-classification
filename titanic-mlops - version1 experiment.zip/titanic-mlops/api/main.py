import mlflow.sklearn
import pandas as pd
from fastapi import FastAPI
from .schemas import TitanicFeatures  # Relative import
import logging
import sqlite3
import time

app = FastAPI()


# Load model (using version 2)
model = mlflow.sklearn.load_model("models:/TitanicBestModel/2")

# Setup logging
logging.basicConfig(filename='api_logs.log', level=logging.INFO, format='%(asctime)s %(message)s')

# SQLite setup
conn = sqlite3.connect('predictions.db')
conn.execute('''CREATE TABLE IF NOT EXISTS predictions
             (timestamp TEXT, features TEXT, prediction INT, probability FLOAT, latency FLOAT)''')
conn.close()

@app.get("/health")
def health():
    return {"status": "OK"}

@app.post("/predict")
def predict(features: TitanicFeatures):
    start_time = time.time()
    
    # Convert to DataFrame (model expects this format)
    input_df = pd.DataFrame([features.model_dump()])
    
    # Predict
    pred = int(model.predict(input_df)[0])  # Convert numpy.int64 to Python int
    prob = float(model.predict_proba(input_df)[0][1])  # Ensure float for consistency
    
    latency = time.time() - start_time
    
    # Log to file
    logging.info(f"Features: {features}, Prediction: {pred}, Prob: {prob}, Latency: {latency}")
    
    # Log to SQLite
    conn = sqlite3.connect('predictions.db')
    conn.execute("INSERT INTO predictions VALUES (?, ?, ?, ?, ?)",
                 (time.strftime("%Y-%m-%d %H:%M:%S"), str(features), pred, prob, latency))
    conn.commit()
    conn.close()
    
    return {"survived": pred, "probability": prob}