from pydantic import BaseModel

class TitanicFeatures(BaseModel):
    Pclass: int
    Sex: int  # 0=female, 1=male
    Age: float
    SibSp: int
    Parch: int
    Fare: float
    Embarked: int  # Encoded: 0=C, 1=Q, 2=S
    IsChild: int
    FamilySize: int
    Title: int  # Encoded title